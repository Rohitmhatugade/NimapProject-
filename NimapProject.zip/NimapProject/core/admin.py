from django.contrib import admin
from .models import Client, Project

admin.site.register(Client)
admin.site.register(Project)